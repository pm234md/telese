rocks_trees = {
   { name = [[system]], root = [[/home/ubuntu/workspace/AdvanSource/.luarocks]] }
}
